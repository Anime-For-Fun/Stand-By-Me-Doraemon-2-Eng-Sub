function handle(r)
   r.content_type = "text/plain"
   r:puts("Hi there!")
end
